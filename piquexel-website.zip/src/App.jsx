
// App.jsx

import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import wimbledonImg from "./assets/images/wimbledon-house.jpg";
import curatorialHouse from "./assets/images/curatorial-house.jpg";
import vueMer from "./assets/images/vue-mer.jpg";
import g21Residences from "./assets/images/g21-residences.jpg";

function HomePage() {
  return (
    <div className="bg-white text-gray-900 font-sans">
      <section className="h-screen flex flex-col justify-center items-center text-center px-6 bg-cover bg-center text-white" style={{ backgroundImage: `url(${wimbledonImg})` }}>
        <h1 className="text-5xl md:text-7xl font-bold tracking-widest uppercase mb-4">
          Piquexel Workshop
        </h1>
        <p className="text-xl md:text-2xl italic max-w-xl">
          Exquisitely Unique Designs for Interiors and Architecture
        </p>
      </section>

      <section id="about" className="py-20 px-6 md:px-20 bg-gray-100">
        <h2 className="text-3xl font-bold mb-6">About Us</h2>
        <p className="max-w-4xl text-lg leading-relaxed">
          PIQUEXEL is a registered and licensed design firm focused on planning,
          documentation, and management of small to large-scale buildings and
          interiors. We blend technology with artistry, offering detailed
          documentation, 3D models, and virtual experiences that help clients
          envision their dream spaces.
        </p>
        <Link to="/about" className="inline-block mt-6 text-blue-600 underline hover:text-blue-800">
          Learn more
        </Link>
      </section>

      <section id="services" className="py-20 px-6 md:px-20">
        <h2 className="text-3xl font-bold mb-10">Our Services</h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {[
            "Interior Concepts + Drawings",
            "Interior Styling",
            "Building Concepts + Drawings",
            "Urban Planning",
            "Project Administration",
            "Developed Designs + Drawings"
          ].map(service => (
            <div key={service} className="border p-6 rounded-lg shadow hover:shadow-lg transition">
              <h3 className="text-xl font-semibold mb-2">{service}</h3>
              <p className="text-sm text-gray-700">
                Learn more about how we translate ideas into detailed, buildable designs.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section id="portfolio" className="py-20 px-6 md:px-20 bg-gray-100">
        <h2 className="text-3xl font-bold mb-10">Featured Projects</h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {[
            { name: "Curatorial House", location: "Toorak, VIC", image: curatorialHouse },
            { name: "Vue Mer Residences", location: "Gosford, NSW", image: vueMer },
            { name: "G21 Residences", location: "Abuja, Nigeria", image: g21Residences },
          ].map(project => (
            <div key={project.name} className="rounded-lg overflow-hidden shadow-md">
              <img src={project.image} alt={project.name} className="h-48 w-full object-cover" />
              <div className="p-4">
                <h3 className="text-xl font-semibold">{project.name}</h3>
                <p className="text-sm text-gray-600">{project.location}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="py-20 px-6 md:px-20 text-center">
        <h2 className="text-3xl font-bold mb-6">Let’s Create Together</h2>
        <p className="text-lg max-w-xl mx-auto mb-6">
          Contact us today to start building your dream space with elegance and innovation.
        </p>
        <a
          href="mailto:dadi@piquexel.com"
          className="inline-block px-6 py-3 bg-black text-white font-medium rounded hover:bg-gray-800"
        >
          Contact Dadi Dindul
        </a>
      </section>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
      </Routes>
    </Router>
  );
}
